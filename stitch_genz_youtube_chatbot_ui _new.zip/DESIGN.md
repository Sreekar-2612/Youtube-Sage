---
name: Studio Alabaster
colors:
  surface: '#faf9f5'
  surface-dim: '#dbdad6'
  surface-bright: '#faf9f5'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f4f0'
  surface-container: '#efeeea'
  surface-container-high: '#e9e8e4'
  surface-container-highest: '#e3e2df'
  on-surface: '#1b1c1a'
  on-surface-variant: '#45464c'
  inverse-surface: '#30312e'
  inverse-on-surface: '#f2f1ed'
  outline: '#76777d'
  outline-variant: '#c6c6cc'
  surface-tint: '#585e6f'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#151b29'
  on-primary-container: '#7e8395'
  inverse-primary: '#c1c6d9'
  secondary: '#b12c15'
  on-secondary: '#ffffff'
  secondary-container: '#fe6346'
  on-secondary-container: '#610a00'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#002116'
  on-tertiary-container: '#698b7c'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dde2f6'
  primary-fixed-dim: '#c1c6d9'
  on-primary-fixed: '#151b29'
  on-primary-fixed-variant: '#414756'
  secondary-fixed: '#ffdad3'
  secondary-fixed-dim: '#ffb4a5'
  on-secondary-fixed: '#3e0400'
  on-secondary-fixed-variant: '#8e1300'
  tertiary-fixed: '#c6ebd9'
  tertiary-fixed-dim: '#abcebe'
  on-tertiary-fixed: '#002116'
  on-tertiary-fixed-variant: '#2d4d40'
  background: '#faf9f5'
  on-background: '#1b1c1a'
  surface-variant: '#e3e2df'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 48px
    letterSpacing: -0.03em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '600'
    lineHeight: 38px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: -0.005em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0em
  label-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
  code-sm:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: -0.01em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  space-2xs: 0.125rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-base: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
  space-3xl: 4.5rem
  gutter-mobile: 1rem
  gutter-desktop: 1.5rem
  sidebar-width: 17.5rem
---

## Brand & Style

This design system embodies the disciplined restraint of contemporary Japanese architecture fused with Scandinavian functionalism. Tailored for high-density cognitive tasks—specifically distilling, annotating, and interrogating multi-hour video transcripts—the interface recedes into an architectural canvas, allowing dense textual synthesis and structural outlines to breathe without friction.

The emotional signature is contemplative, razor-sharp, and tactile. Instead of the sensory fatigue produced by deep-space dark modes or the stark clinical chill of pure white SaaS tools, this system introduces warm porcelain surfaces, hairline geometry, and measured bursts of pigment. The user feels as though they are seated at an oiled hinoki wood desk, arranging vellum prints with fine drafting instruments.

## Colors

The palette grounds itself in organic neutrality, avoiding pure `#FFFFFF` and digital `#000000` entirely. 

- **Surface Neutral (`#F7F6F2`)**: Warm alabaster/porcelain base. Surfaces step upward through micro-tonal shifts rather than aggressive drops: Canvas (`#F7F6F2`), Card/Container (`#FFFFFF`), Inset/Muted Field (`#EFECE6`).
- **Primary Ink Indigo (`#121826`)**: A deep, saturated Prussian ink. Used for authoritative headline typography, primary actions, and acute graphical accents. Replaces utilitarian graphite with deep-water calm.
- **Secondary Persimmon (`#E24F34`)**: A vibrant Japanese vermilion. Deployed sparingly for primary callouts, timestamp scrobblers, live playhead cursors, and generative AI highlights.
- **Tertiary Eucalyptus Sage (`#4A6B5D`)**: An earthy, dried-herb green. Dedicated to semantic completion, citation verifications, synthesis accuracy indicators, and grounded interactive states.
- **Borders & Dividers**: Hairlines (`1px`) anchored strictly to `#E6E3DB` on light canvas and `#DDD9CE` under hover states.

## Typography

Typography relies on a crisp structural pairing: **Plus Jakarta Sans** provides structural elegance and geometric discipline for display surfaces and hierarchical anchors, while **Inter** delivers neutral, transparent cadence across complex, multi-page transcripts and AI synthesis blocks.

- **Tabular & Timestamp Numerals**: All timestamps (`01:24:08`), video metrics, and citation tokens must activate tabular lining numerals (`font-variant-numeric: tabular-nums`) to preserve optical column alignments.
- **Editorial Proportion**: Long-form transcript reading blocks constrain themselves to a maximum line length of 65 characters (`65ch`), ensuring effortless vertical tracking during accelerated review workflows.

## Layout & Spacing

The layout is built upon an asymmetrical split-pane workbench paradigm, balancing fluid adaptability with rigid typographic margins.

- **Grid Structure**:
  - **Desktop (≥ 1280px)**: A 3-pane fixed-fluid-fixed rhythm: Persistent navigation sidebar (`17.5rem`), dynamic multi-column canvas (flexible 12-column sub-grid with `1.5rem` gutters), and contextual intelligence rail (`24rem`).
  - **Tablet (768px – 1279px)**: Dual pane; contextual rail collapses into a slide-over sheet. The transcript and player assume primary focus.
  - **Mobile (< 768px)**: Single stacked view governed by sticky sub-headers and bottom-sheet drawers for transcript exploration. Gutter narrows to `1rem`.

- **Rhythm Principle**: Internal component padding remains dense (`0.5rem` to `1rem`) to keep analytical data compact, while outer section framing utilizes expansive breathing margins (`2rem` to `4.5rem`) to reinforce the uncluttered Scandinavian gallery feel.

## Elevation & Depth

This system intentionally rejects heavy drop shadows, multi-colored diffusions, and frosted-glass skeuomorphism. Depth is established through **architectural plane-stacking** and **subtle ambient occlusion**.

- **Surface Hierarchy**:
  - **Level 0 (Canvas Base)**: `#F7F6F2`. The grounding background for whole-page surfaces.
  - **Level 1 (Structural Cards & Rails)**: `#FFFFFF`. Sharp, pure planes floating directly over Level 0, bounded by a uniform hairline outline (`1px solid #E6E3DB`).
  - **Level 2 (Active Modals, Float Menus, Flyouts)**: `#FFFFFF` paired with an ultra-diffused atmospheric shadow: `0 4px 24px -2px rgba(18, 24, 38, 0.04), 0 1px 2px 0 rgba(18, 24, 38, 0.02)`.
  
- **Micro-Borders**: Every panel, button, and table partition uses a strictly calibrated `1px` stroke. No component relies on ambient blur alone to distinguish its footprint.

## Shapes

The geometry reflects precision paper-craft: crisp, disciplined, and gently softened to avoid razor-edge visual fatigue.

- **Base Radius (`0.25rem` / `4px`)**: Applied to micro-components such as data badges, timestamp links, code spans, and citation chips.
- **Surface Radius (`0.5rem` / `8px`)**: Applied to input controls, interactive cards, secondary panels, and video display frames.
- **Panel Radius (`0.75rem` / `12px`)**: Applied exclusively to high-level container surfaces, such as floating intelligence toolbars and popover dialogs.
- **Pill Exceptions**: Pure capsule shapes (`9999px`) are reserved solely for live state pills, audio scrobbler handles, and active category toggles.

## Components

### Buttons
- **Primary**: Solid Deep Indigo (`#121826`) fill, `#FFFFFF` text, `0.5rem` radius. Tactile state: sub-pixel depression on active (`transform: scale(0.99)`), with no harsh outer glow.
- **Secondary / Outline**: `#FFFFFF` background, `1px solid #E6E3DB`, Deep Indigo text. Transitions to canvas neutral (`#EFECE6`) on hover with border tone intensifying to `#DDD9CE`.
- **Tertiary (Persimmon Action)**: Subtle persimmon wash (`rgba(226, 79, 52, 0.08)`) with `#E24F34` text, shifting to solid persimmon on decisive action triggers (e.g., "Synthesize Key Points").

### Chips & Timestamp Badges
- **Timestamp Chip**: Rectangular with subtle rounding (`0.25rem`). Monospaced text (`JetBrains Mono`), background `#EFECE6`, border `1px solid #E6E3DB`, text `#121826`. On hover, background shifts to persimmon tint (`rgba(226, 79, 52, 0.08)`) and text turns `#E24F34`, indicating immediate seekability.
- **Entity & Concept Tag**: Background `#FFFFFF`, border `1px solid #E6E3DB`, text size `11px` (`label-sm`).

### Lists & Transcript Blocks
- **Transcript Rows**: Composed of two columns: tabular timestamp on the left, running dialogue block on the right. Separated by hairline divider `1px solid #EFECE6`. 
- **Active Dialogue Segment**: Marked by an unshifted left border accent (`2px solid #E24F34`) and a warm micro-highlight background (`rgba(247, 246, 242, 0.6)`).

### Input Fields & Search Bars
- **Workbench Search Bar**: Flush `#FFFFFF` surface with `1px solid #E6E3DB`, `0.5rem` radius, inset icon tint `#8E8B82`. Focused state sheds heavy rings; instead, sharpens cleanly to `1px solid #121826`.

### Cards & Synthesis Artifacts
- **AI Summary Cards**: Pure white card grounded on `#F7F6F2`. Structured with `1.5rem` internal padding, `1px solid #E6E3DB`, no visible drop-shadow. Section dividers within cards utilize subtle dotted strokes (`1px dotted #DDD9CE`).
- **Citation Anchors**: Interactive superscripts (`[1]`, `[2]`) in Sage green (`#4A6B5D`), opening a floating drawer detailing source video context.

### Interactive Scrobbler & Timeline
- High-precision hairline scrubber bar (`2px` height) in `#DDD9CE`, filled dynamically by Persimmon (`#E24F34`). AI-generated chapter clusters sit as discrete tick marks with minimal text tooltips on hover.